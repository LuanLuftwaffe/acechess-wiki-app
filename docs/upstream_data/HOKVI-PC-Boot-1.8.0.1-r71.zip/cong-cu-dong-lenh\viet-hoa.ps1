﻿# Viet hoa HoK Ace - PC 1.8.0.1-r71 - script dieu khien ung dung.
# BAN DICH CONG DONG - KHONG THUONG MAI HOA. Mien phi; neu ban phai tra tien de co ban nay, ban da bi lua.
# Dung qua cac file .bat di kem. Tham so: -Status | -Install | -Restore | -Update | -SafeLaunch | -BaoCao | -Prune
# Ung dung chi la vo: du lieu Viet hoa luon tai tu may chu dung phien ban game (kiem SHA-256).
param(
    [switch]$Status,
    [switch]$Install,
    [switch]$Restore,
    [switch]$Update,
    [switch]$SafeLaunch,
    [switch]$BaoCao,
    [switch]$Prune
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Set-Location -LiteralPath $PSScriptRoot

# Tu 1.3.0.4-r13 cac .bat/.ps1 nam trong thu muc con 'cong-cu-dong-lenh'; exe nam o thu muc cha.
$AppDir = $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $AppDir 'HOKVI-PC-VietHoa.exe'))) { $AppDir = Split-Path -Parent $PSScriptRoot }
$Exe = Get-Item -LiteralPath (Join-Path $AppDir 'HOKVI-PC-VietHoa.exe') -ErrorAction SilentlyContinue
if (-not $Exe) { $Exe = Get-ChildItem -LiteralPath $AppDir -Filter 'HOKVI-PC-VietHoa*.exe' | Select-Object -First 1 }
if (-not $Exe) {
    Write-Host 'Khong tim thay HOKVI-PC-VietHoa.exe trong thu muc nay.' -ForegroundColor Red
    exit 1
}

# File vua tai ve mang danh dau "Mark of the Web"; Smart App Control chan file do.
Get-ChildItem -LiteralPath $AppDir -File -Recurse | ForEach-Object {
    if (Get-Item -LiteralPath $_.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue) {
        Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue
    }
}
$writes = $Install -or $Restore -or $Update -or $SafeLaunch
$sac = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -ErrorAction SilentlyContinue).VerifiedAndReputablePolicyState
if ($writes -and ($sac -eq 1 -or $sac -eq 2)) {
    Write-Host 'Canh bao: Smart App Control dang bat. Windows co the chan bo va' -ForegroundColor Yellow
    Write-Host '(loi "An Application Control policy has blocked this file", os error 4551).' -ForegroundColor Yellow
    Write-Host 'Neu gap loi do, chay 4-go-chan-file.bat roi thu lai.' -ForegroundColor Yellow
    Write-Host ''
}

if ($Prune) {
    & $Exe.FullName --prune
    exit $LASTEXITCODE
}

function Get-GameDir {
    $raw = & $Exe.FullName --discover 2>&1 | Out-String
    $at = $raw.IndexOf('{')
    if ($at -lt 0) { return $null }
    try { return (ConvertFrom-Json $raw.Substring($at)).game_dir } catch { return $null }
}

$gameDir = Get-GameDir
if (-not $gameDir) {
    Write-Host 'Khong tu tim duoc thu muc game.' -ForegroundColor Yellow
    $gameDir = Read-Host 'Nhap duong dan thu muc game (thu muc chua WXQ.exe va WXQ_Data)'
}
if (-not (Test-Path -LiteralPath $gameDir)) {
    Write-Host "Duong dan khong ton tai: $gameDir" -ForegroundColor Red
    exit 1
}
Write-Host "Thu muc game: $gameDir" -ForegroundColor Cyan

if ($BaoCao) {
    Write-Host 'Dang tao bao cao chan doan (vai phut; khong chua du lieu tai khoan)...' -ForegroundColor Cyan
    & $Exe.FullName --bao-cao --game-dir $gameDir
    exit $LASTEXITCODE
}

# Game (WXQ*), launcher chinh thuc (ten tieng Trung, ghep tu ma ky tu de file giu ASCII) va
# moi tien trinh phu nam trong thu muc WXQLauncher; bo qua dich vu chong gian lan ACE.
# Ung dung cung tu kiem lai truoc khi ghi.
$LauncherName = -join ([char[]](0x738B, 0x8005, 0x4E07, 0x8C61, 0x68CB))
$running = Get-Process -ErrorAction SilentlyContinue | Where-Object {
    ($_.Name -match 'WXQ' -or $_.Name -eq $LauncherName -or ($_.Path -and $_.Path -like '*\WXQLauncher\*')) -and
    -not ($_.Path -and $_.Path -like '*\AntiCheatExpert\*') -and $_.Name -notlike 'ACE-*'
}
if ($running -and $writes) {
    Write-Host ('Game hoac launcher dang chay (' + (($running | Select-Object -ExpandProperty Name -Unique) -join ', ') + ').') -ForegroundColor Red
    Write-Host 'Hay thoat han game va launcher (ca bieu tuong duoi khay: chuot phai -> Thoat) roi chay lai.' -ForegroundColor Red
    exit 1
}

function Show-GameInfo {
    $v = Join-Path $gameDir 'WXQ_Data\StreamingAssets\Config\Version.txt'
    $line = Get-Content -LiteralPath $v -ErrorAction SilentlyContinue | Where-Object { $_ -match '^\[Version\s*=' } | Select-Object -First 1
    if ($line) { Write-Host ('Phien ban game: ' + ($line -replace '^\[Version\s*=\s*', '' -replace '\]$', '')) -ForegroundColor Cyan }
}

if ($Status) {
    Show-GameInfo
    & $Exe.FullName --status --game-dir $gameDir
    exit 0
}
if ($Install -or $Update) {
    Show-GameInfo
    Write-Host 'Tai du lieu Viet hoa dung phien ban game tu may chu (kiem SHA-256) roi cai. Vai phut, dung tat cua so.' -ForegroundColor Cyan
    & $Exe.FullName --install --game-dir $gameDir
    if ($LASTEXITCODE -eq 0) { Write-Host 'Hoan tat. Mo game de kiem tra.' -ForegroundColor Green }
    elseif ($LASTEXITCODE -eq 11) { Write-Host 'Chua co ban va cho phien ban game nay - chua cai gi. Xem dong KET LUAN phia tren; khi co ban va, chay lai file nay.' -ForegroundColor Yellow }
    else { Write-Host 'Cai dat chua xong. Xem dong KET LUAN phia tren. Thu lai: chay lai file .bat nay; van loi thi chay 7-bao-cao-chan-doan.bat va gui tep bao cao.' -ForegroundColor Red }
    exit $LASTEXITCODE
}
if ($SafeLaunch) {
    Show-GameInfo
    Write-Host 'MO GAME AN TOAN: go ban va (doi chieu ban goc) -> mo launcher -> cho launcher va game thoat han -> cai lai.' -ForegroundColor Cyan
    Write-Host 'Nho: de launcher cap nhat XONG roi THOAT HAN launcher (ca bieu tuong duoi khay). Dung dong cua so nay.' -ForegroundColor Yellow
    & $Exe.FullName --safe-launch --game-dir $gameDir
    $code = $LASTEXITCODE
    if ($code -eq 0) { Write-Host 'Hoan tat. Mo game binh thuong de choi ban Viet hoa.' -ForegroundColor Green }
    elseif ($code -eq 11) { Write-Host 'Game da cap nhat nhung chua co ban va - game o ban goc, choi binh thuong. Khi co ban va, chay 2-cai-dat.bat.' -ForegroundColor Yellow }
    elseif ($code -eq 3) { Write-Host 'Da huy cho: game dang o ban goc. Chay 2-cai-dat.bat de Viet hoa lai.' -ForegroundColor Yellow }
    else { Write-Host 'Mo game an toan dung lai. Xem dong KET LUAN phia tren. Thu lai: chay lai file .bat nay; van loi thi chay 7-bao-cao-chan-doan.bat.' -ForegroundColor Red }
    exit $code
}
if ($Restore) {
    Write-Host 'Dang go ban Viet hoa va doi chieu tung tep voi ban goc...' -ForegroundColor Cyan
    & $Exe.FullName --restore --game-dir $gameDir
    $code = $LASTEXITCODE
    if ($code -eq 0) { Write-Host 'Da khoi phuc ban goc.' -ForegroundColor Green }
    else { Write-Host 'Khoi phuc chua xong. Xem dong KET LUAN phia tren. Thu lai: chay lai file .bat nay; van loi thi chay 7-bao-cao-chan-doan.bat.' -ForegroundColor Red }
    exit $code
}

& $Exe.FullName
