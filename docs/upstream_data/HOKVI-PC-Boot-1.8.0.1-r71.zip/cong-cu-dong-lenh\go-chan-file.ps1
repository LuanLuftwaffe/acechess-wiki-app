# Xu ly loi "An Application Control policy has blocked this file" (os error 4551).
# Nguyen nhan: Windows 11 Smart App Control / WDAC chan file chua ky so, dac biet khi
# file vua tai ve (co danh dau Mark of the Web).

$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $Root 'HOKVI-PC-VietHoa.exe'))) { $Root = $PSScriptRoot }
Set-Location -LiteralPath $Root

Write-Host '== Buoc 1: bo danh dau "tai tu Internet" cho moi file trong thu muc' -ForegroundColor Cyan
$count = 0
Get-ChildItem -LiteralPath $Root -Recurse -File | ForEach-Object {
    $stream = Get-Item -LiteralPath $_.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue
    if ($stream) { Unblock-File -LiteralPath $_.FullName; $count++ }
}
Write-Host ("   da bo danh dau cho {0} file" -f $count) -ForegroundColor Green

Write-Host '== Buoc 2: kiem tra Smart App Control' -ForegroundColor Cyan
$state = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -ErrorAction SilentlyContinue).VerifiedAndReputablePolicyState
switch ($state) {
    0 { Write-Host '   Smart App Control: TAT. Neu van bi chan, xem Buoc 3.' -ForegroundColor Green }
    1 { Write-Host '   Smart App Control: DANG BAT -> day chinh la thu chan ban va.' -ForegroundColor Yellow }
    2 { Write-Host '   Smart App Control: che do Danh gia -> co the chan ban va.' -ForegroundColor Yellow }
    default { Write-Host '   Khong doc duoc trang thai (may cu hoac ban Windows khong co tinh nang nay).' }
}

if ($state -eq 1 -or $state -eq 2) {
    Write-Host ''
    Write-Host '   Cach tat: Windows Security > App & browser control > Smart App Control settings > Off' -ForegroundColor Yellow
    Write-Host '   Luu y: tat roi thi khong bat lai duoc neu khong cai lai Windows.' -ForegroundColor Yellow
    $answer = Read-Host '   Mo thang trang cai dat Smart App Control bay gio? (y/n)'
    if ($answer -match '^(y|Y)') { Start-Process 'windowsdefender://smartappcontrol' }
}

Write-Host ''
Write-Host '== Buoc 3: neu van bi chan' -ForegroundColor Cyan
Write-Host '   - Chep ca thu muc nay ra o dia trong may (vi du D:\VietHoa) roi chay lai 2-cai-dat.bat'
Write-Host '   - Hoac tam tat Real-time protection cua Windows Security, cai xong bat lai'
Write-Host '   - Phan chu co the da cai xong truoc khi bi chan; chay lai 2-cai-dat.bat se cai not phan font'
Write-Host ''
Write-Host 'Xong. Chay lai 2-cai-dat.bat de tiep tuc.' -ForegroundColor Green
