@echo off
chcp 65001 >nul
title Mo game an toan - Viet hoa HoK Ace PC 1.6.0.1-r36
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Can quyen Administrator, dang mo lai...
  powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0viet-hoa.ps1" -SafeLaunch
echo.
pause
