@echo off
chcp 65001 >nul
title Go chan file - Viet hoa HoK Ace
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Can quyen Administrator, dang mo lai...
  powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0go-chan-file.ps1"
echo.
pause
