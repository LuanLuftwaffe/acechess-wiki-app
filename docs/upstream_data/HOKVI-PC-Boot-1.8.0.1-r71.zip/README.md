# Việt hoá HoK Ace — PC 1.8.0.1-r71

**BẢN DỊCH CỘNG ĐỒNG – KHÔNG THƯƠNG MẠI HOÁ.** Miễn phí, do cộng đồng làm. Nếu bạn phải trả tiền
để có bản này, bạn đã bị lừa.

Bản vá tiếng Việt cho game cờ tự động **Honor of Kings: Ace / 王者万象棋** (Tencent), bản PC.
Toàn bộ chữ được dịch lại từ **nguồn tiếng Trung**, thuật ngữ theo cách gọi quen thuộc của game
thủ Việt (Đấu Trường Chân Lý / Liên Quân / Vương Giả Vinh Diệu).

**Bản:** 1.8.0.1-r71 · **Ngày:** 15/10/2026 · Dành cho game **1.8.0.1** · Cùng kiểu tên với bản
Android (`HOKVI-Android-VietHoa-1.8.0.1-r71`). Bấm **Có gì mới** trong cửa sổ để xem nhật ký
thay đổi, **Hướng dẫn sử dụng** để xem cách dùng từng bước.

---

## 1. Ứng dụng này là "vỏ" — dữ liệu luôn tải từ máy chủ

`HOKVI-PC-VietHoa.exe` không mang sẵn bản dịch. Mỗi lần Kiểm tra / Cài đặt / Gỡ, ứng dụng:

1. đọc phiên bản game trên máy (`WXQ_Data\StreamingAssets\Config\Version.txt`);
2. hỏi máy chủ bộ dữ liệu Việt hoá **đúng phiên bản game đó** (cùng danh mục với bản Android);
3. tải (lần đầu, khoảng 130 MB), **kiểm SHA-256**, giải nén vào
   `%LOCALAPPDATA%\HoK-Ace-Viet-Hoa\pc\<bản>\` — lần sau không tải lại;
4. chạy bộ cài từ dữ liệu đó.

Game mới hơn bản vá đã kiểm (launcher vừa cập nhật mà bản vá mới chưa ra) thì vẫn cài được bản
mới nhất, nhưng cửa sổ báo rõ: *"Game … mới hơn bản vá đã kiểm (…), một phần chữ/ảnh mới có thể
còn tiếng Trung — đợi bản vá mới."* Mất mạng thì dùng dữ liệu đã tải trước đó (có báo).

Ứng dụng **tự cập nhật**: có bản mới thì thẻ trên cùng hiện nút **Cập nhật ứng dụng** (tải, kiểm SHA-256,
thay exe rồi mở lại). Các bản Việt hoá PC cũ đã cài trên máy khác cũng được mời lên bản này qua
nút cập nhật của chúng.

## 1b. Tiến độ và tốc độ

- Khi cài/gỡ, cửa sổ hiện **giai đoạn đang chạy** (đọc gói + dịch bảng + ảnh thẻ, dựng lại gói,
  hoán đổi tệp…), thanh %, thời gian đã chạy và **ước còn lại** (theo lần chạy trước).
- **Lần cài đầu** trên một phiên bản game phải dựng lại các gói dữ liệu (lâu nhất — xem số đo trong
  "Có gì mới"). Gói đã dựng được giữ trong **bộ đệm** `%LOCALAPPDATA%\HoK-Ace-Viet-Hoa\cache\`
  (kiểm SHA-256). **Cài lại** trên cùng phiên bản game (sau khi Gỡ, sau Mở game an toàn khi game
  không đổi…) chỉ còn chép + hoán đổi.
- Bấm **Cài Việt hoá** khi bản vá này đã được cài đúng: ứng dụng nhận ra (so SHA-256) và không gỡ/dựng
  lại nữa.
- Bộ đệm chỉ giữ cho phiên bản game hiện tại; "Dọn dữ liệu cũ" xoá bộ đệm của phiên bản cũ.

## 2. Cần chuẩn bị

- Windows 10 hoặc 11 (64-bit), có mạng (lần đầu).
- Đã cài game (WXQLauncher). Ứng dụng tự tìm thư mục game.
- **Thoát game** trước khi cài/gỡ. Launcher 王者万象棋 đang **kiểm tra/tải cập nhật** thì giữ tệp game
  và làm việc cài đứng: ứng dụng hỏi Windows tiến trình nào đang giữ tệp, có thì **chờ** và chỉ rõ tên
  (nút **Đóng launcher giúp tôi**). Launcher chỉ mở mà không giữ tệp thì vẫn cài được — đừng bấm cập
  nhật/kiểm tra game trong launcher lúc đang cài.
- Quyền Administrator (game thường nằm trong `C:\Program Files`), khoảng 1 GB trống.

## 3. Dùng nhanh

1. Giải nén thư mục này ra ổ cứng (không chạy trong file zip).
2. Bấm đúp **`HOKVI-PC-VietHoa.exe`**. Thấy dòng "cần quyền Administrator" thì bấm
   **Cấp quyền và mở lại** → **Yes**.
3. Bấm **Cài Việt hoá**. Xong khi thẻ trên cùng chuyển xanh **Đã Việt hoá**.

Cửa sổ (từ r17) gọn cho người mới: trên cùng là **thẻ tình trạng** — một câu nói game đang thế nào
và **một nút** việc cần làm (Tự tìm thư mục game / Cấp quyền và mở lại / Cài Việt hoá / Mở game an
toàn / Cập nhật ứng dụng / **Thử lại**). Có lỗi thì thẻ báo rõ lỗi gì kèm **Thử lại** và **Tạo báo
cáo lỗi**. Các thao tác khác nằm trong mục thu gọn **Tuỳ chọn và thao tác khác**; chi tiết phiên
bản và nhật ký kỹ thuật cũng được thu gọn. Nút **Hướng dẫn sử dụng** ở đầu cửa sổ có đủ các chương:
lần đầu cài, khi game có bản cập nhật, khi ứng dụng có bản mới, khôi phục bản gốc, lỗi thường gặp.

| Nút | Làm gì |
|---|---|
| **Kiểm tra game** | Chỉ đọc. KẾT LUẬN: đã Việt hoá đầy đủ / chưa / bị cập nhật game ghi đè một phần; kèm ước tính dọn dữ liệu cũ. |
| **Cài Việt hoá** | Tải dữ liệu đúng phiên bản game (kiểm SHA-256) rồi cài. Đang có bản vá cũ thì gỡ trước để luôn gỡ được về bản gốc. |
| **Khôi phục bản gốc** | Gỡ Việt hoá và **chứng minh khôi phục 100%** (mục 5). |
| **Tạo báo cáo lỗi** | Tệp zip trên Desktop để gửi người hỗ trợ (mục 7). |
| **Dọn dữ liệu cũ** | Xoá sao lưu/dữ liệu cũ, giữ đúng thứ cần để gỡ (mục 6). |
| **Mở game an toàn** | Gỡ → mở launcher → chờ thoát → tự cài lại (mục 4). |
| **Gỡ để cập nhật game** | Chỉ gỡ (có đối chiếu bản gốc); cập nhật game xong thì bấm **Cài Việt hoá**. |
| **Có gì mới** | Nhật ký thay đổi các bản (dùng chung với bản Android). |

## 4. Cập nhật game + Việt hoá — dùng "Mở game an toàn"

Game đang mang bản vá thì launcher coi các gói dữ liệu đã sửa là "hỏng" và **tải lại NGUYÊN gói**
(lần 1.3.0.3 → 1.3.0.4: khoảng 2,4 GB). Game ở bản gốc thì launcher chỉ tải **phần thay đổi**.

Khi game có bản cập nhật, chỉ cần bấm **Mở game an toàn** (hoặc `cong-cu-dong-lenh\6-mo-game-an-toan.bat`).
Ứng dụng làm trọn 3 bước:

1. **Trả về bản gốc (tự động).** Gỡ bản vá và đối chiếu từng tệp với bản gốc. Chưa về đúng 100%
   thì **không mở launcher** và nói rõ cần làm gì (xem mục 5).
2. **Để launcher cập nhật.** Ứng dụng mở launcher 王者万象棋 (tự tìm cạnh thư mục game). Bạn để launcher
   cập nhật xong, rồi **thoát hẳn game và launcher** (kể cả dưới khay). Đừng đóng cửa sổ Việt hoá.
   Launcher tự cập nhật rồi mở lại cũng không sao — chỉ tính là "đã thoát" khi vắng mặt 10 giây liền.
   `ACE-Service64.exe` (chống gian lận) chạy tiếp cũng không sao.
3. **Việt hoá bản mới (tự động).** Có bản vá cho phiên bản game mới → tự cài (thường vài phút nhờ
   *cài nhanh*). Chưa có bản vá → báo **"chưa có bản vá"**: cứ chơi bản gốc, khi có bản vá ứng dụng sẽ báo.

**Lỡ cập nhật game khi còn Việt hoá** (vd. game lên 1.4.0.1 khi đang cài bản cho 1.3.0.4): cứ bấm
**Cài Việt hoá**. Launcher thường tải lại gần hết các gói, nhưng có gói nó không đụng tới nên vẫn còn bản vá cũ
(máy chúng tôi: gói `1050019411`). Ứng dụng chỉ trả gói đó về bản gốc từ bản sao lưu khi **có đủ bằng chứng**
launcher chưa hề đổi gói: (a) kích thước tệp = đúng bản vá cũ, (b) cả tệp trùng từng byte với bản vá cũ, nên mọi
phần bản vá không chạm vẫn trùng bản sao lưu gốc; bản sao lưu cũng phải đúng SHA-256. Nhật ký ghi rõ quy tắc đã
cho phép. Không đủ bằng chứng (launcher đã đổi một phần gói, bản sao lưu thiếu/hỏng) thì ứng dụng **không** chép
bản sao lưu cũ lên game mới, mà nhờ bạn mở launcher → **Sửa chữa / Kiểm tra tệp (修复)** rồi bấm lại.

| Tình huống | Chuyện gì xảy ra |
|---|---|
| Game/launcher đang chạy, hoặc bấm **No** ở hộp thoại quyền | Không làm gì, bản Việt hoá giữ nguyên. |
| Không tìm thấy launcher | Không làm gì. Làm tay: **Gỡ để cập nhật game** → mở launcher → thoát → **Cài Việt hoá**. |
| Gỡ chưa trọn vẹn | Không mở launcher; KẾT LUẬN liệt kê tệp lệch và hướng dẫn sửa. |
| Bấm **Huỷ chờ** / đóng cửa sổ giữa chừng | Game ở bản gốc cho tới khi bấm **Cài Việt hoá** (nút **Thử lại**). |

### Tuỳ chọn: hình minh hoạ Quy tắc cơ bản

Trong *Tuỳ chọn và thao tác khác* có ô **Việt hoá hình minh hoạ Quy tắc cơ bản (Bách khoa)** — hình minh hoạ
trong Bách khoa: Quy tắc cơ bản, ải luyện tập, trang trợ giúp, bìa video từ khoá (gói game 1050085589). **Mặc định bật**
từ bản r50 (tải thêm một gói hình); ai đã tự tắt trước đó vẫn giữ tắt.
Bật: ứng dụng tải gói hình (kiểm SHA-256, mã hoá như dữ liệu chính) và dựng lại đúng gói đó; tắt: trả đúng gói đó
về bản gốc (có sao lưu + đối chiếu). Lựa chọn được nhớ cho các lần Cài Việt hoá / Mở game an toàn sau. Dòng lệnh:
`HOKVI-PC-VietHoa.exe --quy-tac on|off`. **Khôi phục bản gốc** trả cả gói hình về gốc. Khi game cập nhật, launcher
có thể tải lại gói này như các gói khác — dùng **Mở game an toàn** như thường lệ.

### Tuỳ chọn: hiệu ứng tướng trong trận (r64)

Ô **Hiệu ứng tướng trong trận** — chữ thư pháp Việt cho hiệu ứng Vô Song của Lữ Bố (vòng cảnh báo dưới sàn) và Thịnh Thế
của Võ Tắc Thiên (chữ hiện trên màn hình). **Mặc định tắt**: không tải, không ghi gì. Bật: ứng dụng tải một gói nhỏ (~7 MB,
kiểm SHA-256, mã hoá như dữ liệu chính) và áp lên gói game 20 đã Việt hoá; tắt: trả gói 20 về đúng bản Việt hoá chính.
Lựa chọn được nhớ cho các lần Cài Việt hoá sau. Dòng lệnh: `HOKVI-PC-VietHoa.exe --hieu-ung on|off`.
**Khôi phục bản gốc** trả cả phần này về gốc.

### Game lên bản mới hơn bản vá

Ứng dụng đọc danh mục (đã ký số) của nhóm Việt hoá và so với phiên bản game trên máy:

- **Có bản vá** cho phiên bản đó → như bình thường.
- Nhóm **xác nhận** bản vá cũ vẫn dùng được → cài bình thường, ghi rõ đang dùng bản vá của phiên bản nào.
- **Chưa có bản vá** → thẻ trên cùng báo *"Game đã lên … — chưa có bản vá"*, nút **Khôi phục bản gốc**: trả game
  về bản gốc để launcher cập nhật, chơi bản gốc; khi có bản vá ứng dụng sẽ báo. Ứng dụng **không bao giờ** vá game
  bằng bản vá không hợp — Mở game an toàn cũng chỉ cài lại khi có bản vá cho phiên bản game sau cập nhật.
- Nhóm biết game **sắp/đã có bản mới hơn** máy đang có → thẻ báo *"Game có bản mới …"* kèm các bước.

**Thông báo nền (tuỳ chọn, mặc định tắt):** trong *Tuỳ chọn và thao tác khác* bật ô **Thông báo khi game/bản vá
có bản mới**. Ứng dụng đăng ký một lịch của riêng tài khoản Windows (khi đăng nhập + mỗi ngày một lần, không cần
quyền Administrator) chạy ẩn `HOKVI-PC-VietHoa.exe --check-quiet`: hỏi máy chủ, hiện tối đa một thông báo cho
mỗi tin mới (game có bản mới / đã có bản vá / ứng dụng có bản mới) rồi thoát. Không bao giờ cài hay tải dữ liệu
từ nền. Bỏ chọn ô là xoá lịch.

## 5. Gỡ và chứng minh khôi phục 100%

Lúc cài từ trạng thái gốc, ứng dụng ghi **sổ bản gốc** (SHA-256 của từng tệp bản vá chạm vào) vào
`%LOCALAPPDATA%\HoK-Ace-Viet-Hoa\goc\`. Sau khi gỡ, mọi tệp được so **từng byte** với sổ và dò
thêm tệp nào còn mang bản vá theo biên nhận của trình cài:

- Đúng hết: **"KẾT LUẬN: Khôi phục 100% — đã đối chiếu N tệp"**.
- Lệch: gỡ lại một lần; vẫn lệch thì liệt kê từng tệp và hướng dẫn mở launcher → **Sửa chữa /
  Kiểm tra tệp (修复)** để tải lại đúng tệp gốc.
- Máy cài từ bản cũ chưa có sổ: ứng dụng quét thêm nội dung game để chắc không còn chữ/ảnh Việt
  hoá (chậm hơn vài phút).

Vì sao Cài Việt hoá luôn gỡ lớp cũ trước: trình cài chỉ giữ sao lưu của lần cài gần nhất; cài chồng
lần hai thì sao lưu gốc của lần đầu bị xoá và không bao giờ gỡ về bản gốc được nữa.

## 6. Dọn dữ liệu cũ — không để dữ liệu chồng chất

Tự chạy sau mỗi lần Cài đặt / Gỡ (và **Dọn dữ liệu cũ** / `cong-cu-dong-lenh\8-don-du-lieu-cu.bat`). Chỉ giữ thứ
cần để gỡ bản đang cài. Xoá:

- sao lưu của lần cài cũ không còn khớp tệp game (game đã cập nhật) — cùng quy tắc với chính
  trình cài; sao lưu còn khớp thì **giữ**;
- dữ liệu Việt hoá đã tải của bản khác bản đang dùng;
- thư mục tạm của các lần chạy trước, exe cũ sau khi tự cập nhật.

KẾT LUẬN có dòng **"Dọn dữ liệu cũ: đã xoá N mục, giải phóng X MB."** (Kiểm tra thì chỉ ước tính).
Muốn giữ một thư mục sao lưu nào đó, đặt tệp `GIU-LAI.txt` vào thư mục khoá của nó.

## 7. Báo cáo chẩn đoán

**Tạo báo cáo lỗi** (hoặc `cong-cu-dong-lenh\7-bao-cao-chan-doan.bat`, `--bao-cao`) tạo
`bao-cao-chan-doan-<giờ>.zip` trên Desktop và mở thư mục chứa nó. Gồm: bản ứng dụng, Windows,
CPU/RAM, dung lượng trống, quyền Administrator, Smart App Control/Defender, thư mục + phiên bản
game, launcher, tiến trình game đang chạy, kết quả Kiểm tra, danh sách sao lưu/bộ đệm, kết quả đọc
máy chủ, trạng thái Mở game an toàn gần nhất, vài nhật ký gần nhất.
**Không** chứa dữ liệu tài khoản / đăng nhập (Tencent, WeGame, QQ, WeChat, cookie…), số serial,
địa chỉ MAC hay tệp cá nhân.

## 8. File .bat và dòng lệnh

Các file .bat nằm trong thư mục con **`cong-cu-dong-lenh`** (thư mục ứng dụng chỉ còn
`HOKVI-PC-VietHoa.exe` và README): `1-kiem-tra` · `2-cai-dat` · `3-go-cai-dat` · `4-go-chan-file` ·
`5-cap-nhat-tu-may-chu` (như Cài đặt) · `6-mo-game-an-toan` · `7-bao-cao-chan-doan` ·
`8-don-du-lieu-cu`. Dòng lệnh cũng in tiến độ (giai đoạn, số bảng/ảnh, ước còn lại).

```bat
HOKVI-PC-VietHoa.exe --status      [--game-dir "C:\Program Files\WXQLauncher\WXQ"]
HOKVI-PC-VietHoa.exe --install     [--game-dir ...]
HOKVI-PC-VietHoa.exe --restore     [--game-dir ...]
HOKVI-PC-VietHoa.exe --safe-launch [--game-dir ...]
HOKVI-PC-VietHoa.exe --prune [--dry-run]
HOKVI-PC-VietHoa.exe --bao-cao
HOKVI-PC-VietHoa.exe --verify-bundle | --check-update | --self-update | --changelog | --discover
```

Mã thoát: 0 xong; 3 huỷ chờ; 4 game/launcher đang chạy; 5 thiếu quyền; 6 không thấy launcher;
7 gỡ chưa trọn trong Mở game an toàn; 8 gỡ chưa trọn.

## 9. Cách đặt tên

`<phiên bản game>-r<số bản>` như bản Android: `1.8.0.1-r71` = cho game 1.4.0.1, bản phát hành
thứ 27. Tệp: `HOKVI-PC-VietHoa-1.8.0.1-r71.zip` (ứng dụng), `HOKVI-PC-Data-1.8.0.1-r71.zip` (dữ
liệu, ứng dụng tự tải). Trong gói dữ liệu có một exe chuyển tiếp mang tên cũ, chỉ để các bản cũ
tự cập nhật được — không cần dùng.

## 10. Bản vá làm gì với game

- Chỉ sửa **chữ, font và ảnh thẻ** trong dữ liệu game; giữ icon, chữ Hán, hình ảnh khác.
- Sao lưu tệp gốc trước khi sửa; gỡ được và chứng minh được bất cứ lúc nào.
- Không đụng tài khoản, luật chơi, mạng.

## 11. Lỗi thường gặp

| Hiện tượng | Cách xử lý |
|---|---|
| `Access is denied` / không ghi được | **Cấp quyền và mở lại**, hoặc Run as administrator |
| "Launcher đang dùng tệp game…" | Chờ launcher xong việc, hoặc tắt hẳn launcher (cả dưới khay) / bấm **Đóng launcher giúp tôi**; ứng dụng tự chạy tiếp |
| "Worker không phản hồi" | Làm theo dòng hướng dẫn (thường là launcher còn chạy); cần hỗ trợ thì **Tạo báo cáo lỗi** |
| Không tải được dữ liệu | Kiểm tra mạng; đã tải trước đó thì vẫn dùng được |
| **SHA-256 LỆCH** | Tệp tải hỏng, đã tự xoá — bấm lại |
| Game cập nhật xong, chữ về tiếng Trung | Bình thường: bấm **Cài Việt hoá**. Lần sau dùng **Mở game an toàn** |
| Khôi phục chưa trọn vẹn | Launcher → **Sửa chữa / Kiểm tra tệp (修复)** |
| SmartScreen cảnh báo | **More info → Run anyway** (bản vá cộng đồng, không ký số) |
| `An Application Control policy has blocked this file` (os error 4551) | Chạy **`cong-cu-dong-lenh\4-go-chan-file.bat`** rồi thử lại; tắt Smart App Control nếu vẫn bị chặn |
| Chữ trên thẻ bị ngắt giữa từ | Giới hạn của engine game (xuống dòng theo từng ký tự) |
| Cần hỗ trợ | **Tạo báo cáo lỗi** rồi gửi tệp zip |

## 12. Kiểm tra tính toàn vẹn

```powershell
Get-FileHash ".\HOKVI-PC-VietHoa.exe" -Algorithm SHA256
```

Giá trị đúng nằm trong `SHA256SUMS.txt` đi kèm. Dữ liệu tải về được ứng dụng tự kiểm SHA-256.

## 13. Ghi chú

**BẢN DỊCH CỘNG ĐỒNG – KHÔNG THƯƠNG MẠI HOÁ.** Bản vá do cộng đồng làm, miễn phí, không liên kết với
Tencent. Dùng cho mục đích cá nhân. Ứng dụng chỉ cài dữ liệu Việt hoá từ kho chính thức (kiểm SHA-256);
bản ứng dụng đã bị sửa hiện dải đỏ "Bản này đã bị sửa — không phải bản chính chủ. Bản chính chủ là bản dịch cộng đồng, làm miễn phí, không thu lợi nhuận. Hãy tải bản chính thức." (kèm liên kết tải chính thức) và không cài được.
