@echo off
chcp 65001 >nul
title Kiem tra game - Viet hoa HoK Ace PC 1.6.0.1-r36
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0viet-hoa.ps1" -Status
echo.
pause
